curl -XPOST -d @mock_payload.json http://localhost:6000/create?room_name=alertManagerTestRoom -i
