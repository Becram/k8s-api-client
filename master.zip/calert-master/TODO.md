-   [x] Add route for inserting new alert

-   [x] Parse alertmanager reponse

-   [x] Add example payload - curl script

-   [x] Log only errors (unix philosophy)

-   [x] Response check from google chat

-   [x] Gomod

-   [x] Refactor to new name

-   [x] Add tests

-   [x] Use middleware to pass around args/context/return err signature instead of naked returns (ugly! \*must fix)

-   [x] Goreleaser binary

-   [x] Images (Google chat instructions + bot usage (gif) + Logo)

-   [x] Add documentation + comments everywhere

-   [x] Add License, CoC, CONTRIBUTION.md

-   [x] Add support for chat room param, so people can use multiple chat rooms based on alertmanager config (DUH! How could I possibly miss this)

-   [ ] Add metrics handler (feature request)

-   [ ] Add verbose mode (optional, low priority)
